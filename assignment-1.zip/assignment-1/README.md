# Assignment 1

A Pen created on CodePen.io. Original URL: [https://codepen.io/kgollwitzer/pen/xxJWyOP](https://codepen.io/kgollwitzer/pen/xxJWyOP).

